/*
 * ccsds.h
 * SCK-2400 Firmware -- SpaceCommsKit
 *
 * Purpose:
 *   CCSDS Space Packet Protocol definitions and framing utilities.
 *   Implements CCSDS 133.0-B-2 primary header and APID assignments.
 *
 * SCK-DEV: CCSDS_APID -- To add a new packet type:
 *          1. Add a new CCSDS_APID_* define below
 *          2. Add a handler case in uart_task() dispatch (uart.c)
 *          3. Add a build function ccsds_build_<type>() here
 *
 * Reference: SCK-2400_Firmware_Requirements.md Section 3.5
 */

#ifndef CCSDS_H
#define CCSDS_H

/* -----------------------------------------------------------------------
 * Includes
 * --------------------------------------------------------------------- */
#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * CCSDS Primary Header
 * CCSDS 133.0-B-2, 6 bytes total.
 *
 *   Bits 15-13: Version (3 bits, always 0b000)
 *   Bit  12:    Type (0=telemetry, 1=command)
 *   Bit  11:    Secondary header flag
 *   Bits 10-0:  APID (11 bits, 0x000-0x7FF)
 *
 *   Bits 15-14: Sequence flags (2 bits)
 *   Bits 13-0:  Sequence count (14 bits)
 *
 *   Bits 15-0:  Packet data length - 1
 * --------------------------------------------------------------------- */
typedef struct __attribute__((packed))
{
    uint16_t version_type_shf_apid;  /* version[3] type[1] shf[1] apid[11] */
    uint16_t seq_flags_count;        /* seq_flags[2] seq_count[14]          */
    uint16_t data_length;            /* packet data length - 1              */
} ccsds_primary_header_t;            /* 6 bytes total                       */

/* -----------------------------------------------------------------------
 * APID Assignments (11-bit, 0x000-0x7FF)
 * SCK-DEV: CCSDS_APID -- Add new packet types here.
 * --------------------------------------------------------------------- */
#define CCSDS_APID_TLM_BEACON       0x001   /* Telemetry beacon           */
#define CCSDS_APID_COMMAND          0x002   /* Uplink command             */
#define CCSDS_APID_CMD_ACK          0x003   /* Command acknowledgement    */
#define CCSDS_APID_GPS_TLM          0x004   /* GPS telemetry              */
#define CCSDS_APID_BARO_TLM         0x005   /* Barometer telemetry        */
#define CCSDS_APID_IMAGE_CHUNK      0x006   /* Image data chunk           */
#define CCSDS_APID_FILE_LIST        0x007   /* File list                  */
#define CCSDS_APID_TEST             0x1FF   /* Reserved / test            */

/* -----------------------------------------------------------------------
 * Header field masks and shifts
 * --------------------------------------------------------------------- */
#define CCSDS_APID_MASK             0x07FF
#define CCSDS_TYPE_SHIFT            12
#define CCSDS_SHF_SHIFT             11
#define CCSDS_SEQ_COUNT_MASK        0x3FFF
#define CCSDS_SEQ_FLAGS_SHIFT       14

/* Sequence flags */
#define CCSDS_SEQ_UNSEGMENTED       0x3     /* standalone packet */

/* -----------------------------------------------------------------------
 * Public API
 * --------------------------------------------------------------------- */

/*
 * ccsds_get_apid()
 * Extract 11-bit APID from primary header.
 * Parameters:
 *   hdr -- pointer to CCSDS primary header
 * Returns: APID value (0x000-0x7FF)
 */
uint16_t ccsds_get_apid(const ccsds_primary_header_t *hdr);

/*
 * ccsds_build_header()
 * Fill a CCSDS primary header struct.
 * Parameters:
 *   hdr       -- pointer to header to fill
 *   apid      -- 11-bit APID
 *   isCmd     -- true for command packet, false for telemetry
 *   seqCount  -- 14-bit sequence counter (caller maintains)
 *   dataLen   -- length of data field in bytes (header writes dataLen-1)
 */
void ccsds_build_header(ccsds_primary_header_t *hdr,
                        uint16_t apid,
                        bool     isCmd,
                        uint16_t seqCount,
                        uint16_t dataLen);

/*
 * ccsds_validate()
 * Basic sanity check on a received CCSDS packet.
 * Parameters:
 *   buf    -- raw packet buffer (including header)
 *   bufLen -- total bytes in buf
 * Returns: true if header version is valid and length field is consistent.
 */
bool ccsds_validate(const uint8_t *buf, uint16_t bufLen);

#endif /* CCSDS_H */
