/*
 * main.h
 * SCK-2400 Firmware -- SpaceCommsKit
 *
 * Purpose:
 *   Top-level header for sck2400_firmware. Includes common defines,
 *   RTOS task handles, and shared state visible across modules.
 *
 * Target (dev):   CC1352P1F3RGZ on LAUNCHXL-CC1352P-2
 * Target (prod):  CC2652P1FRGZ on SCK-2400 custom board
 * Toolchain:      TI Clang + TI-RTOS7
 *
 * SCK-DEV: This file is the top-level include for all modules.
 *          Add new task handles and shared flags here.
 *
 * Reference: SCK-2400_Firmware_Requirements.md Section 3, 7
 */

#ifndef MAIN_H
#define MAIN_H

/* -----------------------------------------------------------------------
 * Includes
 * --------------------------------------------------------------------- */
#include <stdint.h>
#include <stdbool.h>

/* TI-RTOS */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* -----------------------------------------------------------------------
 * Firmware Version
 * --------------------------------------------------------------------- */
#define SCK2400_FW_VERSION_MAJOR    0
#define SCK2400_FW_VERSION_MINOR    1
#define SCK2400_FW_VERSION_PATCH    0

/* -----------------------------------------------------------------------
 * RTOS Task Stack Sizes (bytes)
 * Per requirements Section 7.
 * --------------------------------------------------------------------- */
#define SCK_TASK_STACK_RF       1024
#define SCK_TASK_STACK_UART      512
#define SCK_TASK_STACK_MAIN      512

/* -----------------------------------------------------------------------
 * RTOS Task Priorities
 * --------------------------------------------------------------------- */
#define SCK_TASK_PRI_RF          2
#define SCK_TASK_PRI_UART        2
#define SCK_TASK_PRI_MAIN        1

/* -----------------------------------------------------------------------
 * Task Handle Externs
 * Defined in main.c, referenced by other modules if needed.
 * --------------------------------------------------------------------- */
extern Task_Handle rfTaskHandle;
extern Task_Handle uartTaskHandle;

#endif /* MAIN_H */
