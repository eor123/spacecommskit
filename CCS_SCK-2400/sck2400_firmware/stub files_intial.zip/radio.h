/*
 * radio.h
 * SCK-2400 Firmware -- SpaceCommsKit
 *
 * Purpose:
 *   RF layer interface. Declares TX/RX functions, power control,
 *   and RF switch control for the SKY13317-373LF.
 *
 * RF Configuration:
 *   Frequency:   2440 MHz (Channel 18)
 *   PHY:         2-GFSK, 250 kbps, 125 kHz deviation
 *   TX Power:    0 dBm bench / +20 dBm field
 *   High PA:     Enabled (txPowerTable_2400_pa5_20)
 *   RF Switch:   SKY13317 -- DIO28 (2.4GHz), DIO29 (PA enable)
 *
 * SCK-DEV: RF_CONFIG -- Change frequency/PHY in sck2400.syscfg,
 *          then update SCK_CMD_SETUP and SCK_CMD_FS below.
 * SCK-DEV: TX_POWER  -- Change bench/field power in radio.c
 *          RF_setTxPower() call. See Section 3.2 of requirements.
 *
 * Reference: SCK-2400_Firmware_Requirements.md Section 3.2, 4.2, 4.3
 */

#ifndef RADIO_H
#define RADIO_H

/* -----------------------------------------------------------------------
 * Includes
 * --------------------------------------------------------------------- */
#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * SysConfig Symbol Aliases
 * SysConfig generates suffixed names for custom PHY. All application
 * code uses these aliases so a PHY rename only touches this block.
 * SCK-DEV: RF_CONFIG -- If PHY suffix changes in SysConfig, update here.
 * --------------------------------------------------------------------- */
#define SCK_RF_MODE      RF_prop_2gfsk250kbps_0
#define SCK_CMD_SETUP    RF_cmdPropRadioDivSetup_2gfsk250kbps_0
#define SCK_CMD_FS       RF_cmdFs_2gfsk250kbps_0
#define SCK_CMD_TX       RF_cmdPropTx_2gfsk250kbps_0
#define SCK_CMD_RX       RF_cmdPropRx_2gfsk250kbps_0
#define SCK_TX_PWR_TABLE txPowerTable_2400_pa5_20

/* -----------------------------------------------------------------------
 * TX Power Levels
 * Build system passes TX_POWER=BENCH or TX_POWER=FIELD via Makefile.
 * SCK-DEV: TX_POWER -- These map to RF_setTxPower() calls in radio.c.
 * --------------------------------------------------------------------- */
#define SCK_TX_POWER_BENCH_DBM      0       /* 0 dBm  -- bench/lab use  */
#define SCK_TX_POWER_FIELD_DBM      20      /* +20 dBm -- field/flight  */

#ifndef TX_POWER
#define TX_POWER BENCH                      /* default to bench if unset */
#endif

/* -----------------------------------------------------------------------
 * RF Switch GPIO (SKY13317-373LF)
 * Controlled directly via GPIO driver -- not RF switch plugin.
 * DIO28 = 2.4GHz path select
 * DIO29 = PA enable
 * --------------------------------------------------------------------- */
#define SCK_RF_SW_2G4_DIO   28
#define SCK_RF_SW_PA_DIO    29

/* -----------------------------------------------------------------------
 * Public API
 * --------------------------------------------------------------------- */

/*
 * radio_init()
 * Initialize the RF driver, open the RF handle, configure the PHY,
 * set TX power per build-time TX_POWER define, and configure RF switch.
 * Must be called once from the RF task before any TX/RX.
 * Returns: true on success, false on RF driver error.
 */
bool radio_init(void);

/*
 * radio_transmit()
 * Transmit a packet over the air.
 * Parameters:
 *   buf  -- pointer to packet data (CCSDS-framed)
 *   len  -- length in bytes
 * Returns: true on successful TX, false on RF error.
 * SCK-DEV: TIMING -- TX blocks until complete. Max ~4ms at 250kbps
 *          for a 128-byte packet.
 */
bool radio_transmit(const uint8_t *buf, uint16_t len);

/*
 * radio_receive()
 * Listen for one incoming packet. Blocking until packet received
 * or timeout expires.
 * Parameters:
 *   buf     -- buffer to write received data into
 *   maxLen  -- size of buf
 *   rxLen   -- actual bytes received (output)
 * Returns: true if packet received, false on timeout or error.
 */
bool radio_receive(uint8_t *buf, uint16_t maxLen, uint16_t *rxLen);

/*
 * radio_setTxPower()
 * Set TX power at runtime (used internally by radio_init).
 * Parameters:
 *   dbm -- power level in dBm (0 or 20)
 */
void radio_setTxPower(int8_t dbm);

/*
 * radio_rfSwitchSet()
 * Drive SKY13317 RF switch GPIOs for selected path.
 * Called internally before TX and RX.
 * Parameters:
 *   txMode -- true for TX path, false for RX path
 */
void radio_rfSwitchSet(bool txMode);

#endif /* RADIO_H */
