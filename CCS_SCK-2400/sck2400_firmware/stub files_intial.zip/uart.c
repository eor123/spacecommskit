/*
 * uart.c
 * SCK-2400 Firmware -- SpaceCommsKit
 *
 * Purpose:
 *   UART payload interface implementation. Handles ESP framing,
 *   packet reception from Pico payload, and command dispatch.
 *
 * SCK-DEV: PAYLOAD_UART -- This is the interface between the CC2652P
 *          and the payload processor (Pico/MicroPython). All data
 *          in and out goes through ESP framing on UART0.
 * SCK-DEV: ADD_COMMAND  -- To add a new command:
 *          1. Add a new APID in ccsds.h
 *          2. Add a case in uart_dispatch() below
 *          3. Implement the handler function
 *
 * Reference: SCK-2400_Firmware_Requirements.md Section 3.4
 */

/* -----------------------------------------------------------------------
 * Includes
 * --------------------------------------------------------------------- */
#include "uart.h"
#include "ccsds.h"
#include "main.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

/* TI Drivers */
#include <ti/drivers/UART2.h>

/* -----------------------------------------------------------------------
 * Static state
 * --------------------------------------------------------------------- */
static UART2_Handle sUartHandle = NULL;
static uint8_t      sRxBuf[ESP_FRAME_HDR_LEN + ESP_MAX_PAYLOAD];

/* -----------------------------------------------------------------------
 * uart_init()
 * --------------------------------------------------------------------- */
bool uart_init(void)
{
    UART2_Params uartParams;
    UART2_Params_init(&uartParams);

    /* SCK-DEV: PAYLOAD_UART -- 921600 8N1, no flow control.
     * DIO12 (RX) and DIO13 (TX) set in sck2400.syscfg. */
    uartParams.baudRate  = SCK_UART_BAUD;
    uartParams.dataLength = UART2_DataLen_8;
    uartParams.stopBits  = UART2_StopBits_1;
    uartParams.parityType = UART2_Parity_NONE;
    uartParams.readMode  = UART2_Mode_BLOCKING;
    uartParams.writeMode = UART2_Mode_BLOCKING;

    sUartHandle = UART2_open(SCK_UART_IDX, &uartParams);
    if (sUartHandle == NULL)
    {
        return false;
    }

    return true;
}

/* -----------------------------------------------------------------------
 * uart_task()
 * Main UART receive loop. Reads ESP frames and dispatches commands.
 * --------------------------------------------------------------------- */
void uart_task(uintptr_t arg0, uintptr_t arg1)
{
    uint8_t  payload[ESP_MAX_PAYLOAD];
    uint16_t payloadLen = 0;

    while (1)
    {
        if (uart_receive(payload, sizeof(payload), &payloadLen))
        {
            /* Dispatch based on CCSDS APID */
            /* SCK-DEV: ADD_COMMAND -- Add new APID cases here */
            if (payloadLen >= sizeof(ccsds_primary_header_t))
            {
                ccsds_primary_header_t *hdr = (ccsds_primary_header_t *)payload;
                uint16_t apid = ccsds_get_apid(hdr);

                switch (apid)
                {
                    case CCSDS_APID_COMMAND:
                        /* TODO: handle uplink command */
                        break;

                    case CCSDS_APID_TLM_BEACON:
                        /* TODO: trigger beacon TX */
                        break;

                    default:
                        /* Unknown APID -- log and discard */
                        break;
                }
            }
        }
    }
}

/* -----------------------------------------------------------------------
 * uart_send()
 * --------------------------------------------------------------------- */
bool uart_send(const uint8_t *payload, uint16_t len)
{
    if (sUartHandle == NULL || payload == NULL || len == 0)
    {
        return false;
    }

    /* Build ESP frame header: 0x22 0x69 len_hi len_lo */
    uint8_t hdr[ESP_FRAME_HDR_LEN];
    hdr[0] = ESP_FRAME_BYTE0;
    hdr[1] = ESP_FRAME_BYTE1;
    hdr[2] = (uint8_t)((len >> 8) & 0xFF);
    hdr[3] = (uint8_t)(len & 0xFF);

    /* Write header then payload */
    size_t written = 0;
    int_fast16_t ret;

    ret = UART2_write(sUartHandle, hdr, ESP_FRAME_HDR_LEN, &written);
    if (ret != UART2_STATUS_SUCCESS)
    {
        return false;
    }

    ret = UART2_write(sUartHandle, payload, len, &written);
    return (ret == UART2_STATUS_SUCCESS);
}

/* -----------------------------------------------------------------------
 * uart_receive()
 * --------------------------------------------------------------------- */
bool uart_receive(uint8_t *buf, uint16_t maxLen, uint16_t *rxLen)
{
    if (sUartHandle == NULL || buf == NULL || rxLen == NULL)
    {
        return false;
    }

    size_t bytesRead = 0;
    int_fast16_t ret;

    /* Read 4-byte ESP header */
    ret = UART2_read(sUartHandle, sRxBuf, ESP_FRAME_HDR_LEN, &bytesRead);
    if (ret != UART2_STATUS_SUCCESS || bytesRead != ESP_FRAME_HDR_LEN)
    {
        return false;
    }

    /* Validate sync bytes */
    if (sRxBuf[0] != ESP_FRAME_BYTE0 || sRxBuf[1] != ESP_FRAME_BYTE1)
    {
        /* Bad frame sync -- discard */
        return false;
    }

    /* Extract payload length */
    uint16_t payLen = ((uint16_t)sRxBuf[2] << 8) | sRxBuf[3];
    if (payLen == 0 || payLen > maxLen || payLen > ESP_MAX_PAYLOAD)
    {
        return false;
    }

    /* Read payload */
    ret = UART2_read(sUartHandle, buf, payLen, &bytesRead);
    if (ret != UART2_STATUS_SUCCESS || bytesRead != payLen)
    {
        return false;
    }

    *rxLen = payLen;
    return true;
}
