/*
 * uart.h
 * SCK-2400 Firmware -- SpaceCommsKit
 *
 * Purpose:
 *   UART payload interface. Declares TX/RX functions and ESP framing
 *   for communication with the payload processor (Pico/MicroPython).
 *
 * Interface:
 *   Peripheral:  UART0
 *   TX:          DIO13 (Pin 17)
 *   RX:          DIO12 (Pin 16)
 *   Baud:        921600, 8N1, no flow control
 *   Framing:     ESP (0x22 0x69 len payload) -- same as SCK-915
 *
 * SCK-DEV: PAYLOAD_UART -- Payload interface details. Pico firmware
 *          sends ESP-framed packets. CC2652P parses and dispatches.
 * SCK-DEV: ADD_COMMAND  -- To add a new command, add an APID case
 *          to uart_dispatch() in uart.c.
 *
 * Reference: SCK-2400_Firmware_Requirements.md Section 3.4
 */

#ifndef UART_H
#define UART_H

/* -----------------------------------------------------------------------
 * Includes
 * --------------------------------------------------------------------- */
#include <stdint.h>
#include <stdbool.h>

/* -----------------------------------------------------------------------
 * ESP Framing Constants
 * Header: 0x22 0x69 followed by 2-byte length, then payload.
 * Same framing as SCK-915 UART0 -- Pico firmware compatible.
 * --------------------------------------------------------------------- */
#define ESP_FRAME_BYTE0     0x22
#define ESP_FRAME_BYTE1     0x69
#define ESP_FRAME_HDR_LEN   4       /* 2 sync + 2 length bytes */
#define ESP_MAX_PAYLOAD     256     /* max payload bytes       */

/* -----------------------------------------------------------------------
 * UART Config
 * --------------------------------------------------------------------- */
#define SCK_UART_BAUD       921600
#define SCK_UART_IDX        0       /* UART0 */

/* -----------------------------------------------------------------------
 * Public API
 * --------------------------------------------------------------------- */

/*
 * uart_init()
 * Initialize UART0 driver at 921600 8N1 on DIO12/DIO13.
 * Must be called once before uart_task() starts.
 * Returns: true on success, false on driver error.
 */
bool uart_init(void);

/*
 * uart_task()
 * TI-RTOS task function. Loops forever reading ESP-framed packets
 * from the payload UART and dispatching to the appropriate handler.
 * Parameters:
 *   arg0, arg1 -- unused RTOS task arguments
 * SCK-DEV: ADD_COMMAND -- Dispatch logic is inside this function.
 */
void uart_task(uintptr_t arg0, uintptr_t arg1);

/*
 * uart_send()
 * Send an ESP-framed packet to the payload processor.
 * Parameters:
 *   payload -- pointer to raw payload bytes (pre-CCSDS-framed or raw)
 *   len     -- payload length in bytes
 * Returns: true on success, false on UART write error.
 * SCK-DEV: PAYLOAD_UART -- Call this to push data to Pico.
 */
bool uart_send(const uint8_t *payload, uint16_t len);

/*
 * uart_receive()
 * Block until a complete ESP-framed packet is received.
 * Parameters:
 *   buf    -- buffer for decoded payload (caller allocates)
 *   maxLen -- size of buf
 *   rxLen  -- actual payload bytes written (output)
 * Returns: true if valid frame received, false on framing error/timeout.
 */
bool uart_receive(uint8_t *buf, uint16_t maxLen, uint16_t *rxLen);

#endif /* UART_H */
